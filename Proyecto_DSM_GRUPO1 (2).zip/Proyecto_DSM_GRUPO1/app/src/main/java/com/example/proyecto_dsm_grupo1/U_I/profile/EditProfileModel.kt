package com.example.proyecto_dsm_grupo1.U_I.profile

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

private const val TAG = "TAG_EDIT_PROFILE"

class EditProfileViewModel(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) : ViewModel() {

    private val authListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
        val user = firebaseAuth.currentUser
        if (user != null) {
            // cargar perfil en cuanto haya usuario
            loadProfileForUid(user.uid)
        }
    }

    init {
        auth.addAuthStateListener(authListener)
    }

    override fun onCleared() {
        super.onCleared()
        auth.removeAuthStateListener(authListener)
    }

    // carga directa a partir de UID (más robusta)
    fun loadProfileForUid(uid: String) {
        loading = true
        firestore.collection("users").document(uid)
            .get()
            .addOnSuccessListener { doc ->
                loading = false
                if (doc != null && doc.exists()) {
                    val nombre = doc.getString("nombre") ?: ""
                    val apellido = doc.getString("apellido") ?: ""
                    val email = doc.getString("email") ?: auth.currentUser?.email.orEmpty()
                    val nivel = doc.getString("nivel") ?: ""
                    val bio = doc.getString("bio") ?: ""
                    profile = UserProfile(uid = uid, nombre = nombre, apellido = apellido, email = email, nivel = nivel, bio = bio)
                } else {
                    profile = UserProfile(uid = uid, nombre = "", apellido = "", email = auth.currentUser?.email.orEmpty(), nivel = "", bio = "")
                }
            }
            .addOnFailureListener { ex ->
                loading = false
                error = ex.localizedMessage ?: "Error al leer perfil"
            }
    }

    var loading by mutableStateOf(false)
        private set

    var error by mutableStateOf<String?>(null)
        private set

    var success by mutableStateOf(false)
        private set

    var profile by mutableStateOf<UserProfile?>(null)
        private set

    fun loadProfile() {
        val user = auth.currentUser
        Log.d(TAG, "loadProfile() - currentUser: $user")
        val uid = auth.currentUser?.uid

        if (!uid.isNullOrBlank()) loadProfileForUid(uid)
        if (uid.isNullOrBlank()) {
            error = "Usuario no autenticado"
            Log.e(TAG, "Usuario no autenticado (uid=null). Asegúrate de iniciar sesión primero.")
            return
        }

        loading = true
        firestore.collection("users").document(uid)
            .get()
            .addOnSuccessListener { doc ->
                loading = false
                if (doc != null && doc.exists()) {
                    // Construir manualmente para evitar problemas de mapeo con data class Kotlin
                    val nombre = doc.getString("nombre") ?: ""
                    val apellido = doc.getString("apellido") ?: ""
                    val nivel = doc.getString("nivel") ?: ""
                    val bio = doc.getString("bio") ?: ""
                    val p = UserProfile(uid = uid, nombre = nombre, apellido = apellido, nivel = nivel, bio = bio)
                    profile = p
                    Log.d(TAG, "Perfil cargado: $p")
                } else {
                    // doc no existe -> crear perfil vacío localmente
                    profile = UserProfile(uid = uid, nombre = "", apellido = "", nivel = "", bio = "")
                    Log.w(TAG, "Documento de perfil no existe para uid=$uid. Se creó perfil vacío local.")
                }
            }
            .addOnFailureListener { ex ->
                loading = false
                error = ex.localizedMessage ?: "Error al leer perfil"
                Log.e(TAG, "Error loadProfile()", ex)
            }
    }

    fun saveProfile(nombre: String, apellido: String, nivel: String, bio: String) {
        val user = auth.currentUser
        val uid = user?.uid
        Log.d(TAG, "saveProfile() uid=$uid")
        if (uid.isNullOrBlank()) {
            error = "Usuario no autenticado"
            Log.e(TAG, "Usuario no autenticado al guardar")
            return
        }

        loading = true
        error = null
        success = false

        val data = mapOf(
            "nombre" to nombre.trim(),
            "apellido" to apellido.trim(),
            "nivel" to nivel,
            "bio" to bio.trim(),
            "email" to (user.email ?: "")
        )

        val docRef = firestore.collection("users").document(uid)

        // Intentar update -> si falla por no existir, set()
        docRef.update(data)
            .addOnSuccessListener {
                loading = false
                profile = profile?.copy(nombre = nombre, apellido = apellido, nivel = nivel, bio = bio)
                success = true
                Log.d(TAG, "Perfil actualizado con update() para uid=$uid")
            }
            .addOnFailureListener { ex ->
                Log.w(TAG, "update falló, intentando set(). Motivo: ${ex.localizedMessage}")
                // si update falla (por doc no existir) usamos set()
                docRef.set(data)
                    .addOnSuccessListener {
                        loading = false
                        profile = UserProfile(uid = uid, nombre = nombre, apellido = apellido, nivel = nivel, bio = bio, email = user.email.orEmpty())
                        success = true
                        Log.d(TAG, "Perfil guardado con set() para uid=$uid")
                    }
                    .addOnFailureListener { ex2 ->
                        loading = false
                        error = ex2.localizedMessage ?: "Error guardando perfil"
                        Log.e(TAG, "Error set()", ex2)
                    }
            }
    }

    fun clearError() { error = null }
    fun clearSuccess() { success = false }
}