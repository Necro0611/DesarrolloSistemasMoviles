package com.example.proyecto_dsm_grupo1.U_I.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Logout
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(
    onBack: () -> Unit = {},
    onPersonalInfo: () -> Unit = {},
    onAiSummaries: () -> Unit = {},
    onExportData: () -> Unit = {},
    onPomodoro: () -> Unit = {},
    onNotificationsPerms: () -> Unit = {},
    onLanguage: () -> Unit = {},
    onHelpSupport: () -> Unit = {},
    onLogout: () -> Unit = {}          // ← Este sí navega a Login
) {
    val primaryGreen = Color(0xFF2DBE71)

    Scaffold(
        bottomBar = {
            // Bottom bar “perfil” seleccionado – por ahora solo decorativo aquí
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Outlined.PlayCircle, null) }, label = { Text("Progreso") })
                NavigationBarItem(selected = false, onClick = {}, icon = { Icon(Icons.Outlined.Description, null) }, label = { Text("Otros") })
                NavigationBarItem(selected = true,  onClick = {}, icon = { Icon(Icons.Outlined.Person, null) }, label = { Text("Perfil") })
            }
        }
    ) { inner ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(inner)
        ) {
            // Encabezado verde con “Configuración”
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
                    .background(
                        Brush.verticalGradient(listOf(Color(0xFF79C78C), Color(0xFF5DBB7A)))
                    )
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White)) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "Atrás")
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("Configuración", style = MaterialTheme.typography.titleLarge.copy(color = Color.White, fontWeight = FontWeight.SemiBold))
                }
            }

            // Tarjeta blanca con saludo
            Card(
                shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                modifier = Modifier
                    .fillMaxSize()
            ) {
                Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // avatar placeholder
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFF2F5F4)),
                            contentAlignment = Alignment.Center
                        ) { Text("👋") }

                        Spacer(Modifier.width(12.dp))
                        Text(
                            "Hola, Joaquin",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                    }

                    // Lista de opciones (todas “clickable”)
                    SettingsItem(
                        leading = { Icon(Icons.Outlined.Person, null) },
                        text = "Información Personal",
                        onClick = onPersonalInfo
                    )
                    SettingsItem(
                        leading = { Icon(Icons.Outlined.Tune, null) },
                        text = "Resúmenes IA",
                        onClick = onAiSummaries
                    )
                    SettingsItem(
                        leading = { Icon(Icons.Outlined.Lock, null) },
                        text = "Exportar Datos",
                        onClick = onExportData
                    )
                    SettingsItem(
                        leading = { Icon(Icons.Outlined.PlayCircle, null) },
                        text = "Pomodoro",
                        onClick = onPomodoro
                    )
                    SettingsItem(
                        leading = { Icon(Icons.Outlined.Notifications, null) },
                        text = "Notificaciones y Permisos",
                        onClick = onNotificationsPerms
                    )
                    SettingsItem(
                        leading = { Icon(Icons.Outlined.Language, null) },
                        text = "Idioma de la Aplicación",
                        onClick = onLanguage
                    )
                    SettingsItem(
                        leading = { Icon(Icons.Outlined.HelpOutline, null) },
                        text = "Ayuda y Soporte",
                        onClick = onHelpSupport
                    )

                    // Logout en rojo
                    SettingsItem(
                        leading = { Icon(Icons.Outlined.Logout, null, tint = Color(0xFFE53935)) },
                        text = "Logout",
                        textColor = Color(0xFFE53935),
                        onClick = onLogout
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsItem(
    leading: @Composable () -> Unit,
    text: String,
    textColor: Color = Color(0xFF2F3B45),
    onClick: () -> Unit
) {
    Surface(
        tonalElevation = 1.dp,
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        shadowElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            leading()
            Spacer(Modifier.width(12.dp))
            Text(text, color = textColor, modifier = Modifier.weight(1f))
            Icon(Icons.Outlined.UploadFile, null, tint = Color.Transparent) // placeholder para altura
            Icon(Icons.Outlined.Description, contentDescription = null, tint = Color(0xFF9AA3AF)) // chevron-like
        }
    }
}
