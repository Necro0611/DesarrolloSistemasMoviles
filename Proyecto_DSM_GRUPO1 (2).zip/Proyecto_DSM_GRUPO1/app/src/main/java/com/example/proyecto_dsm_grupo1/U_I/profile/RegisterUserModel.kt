package com.example.proyecto_dsm_grupo1.U_I.profile

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.example.proyecto_dsm_grupo1.U_I.profile.UserProfile

data class RegisterUiState(
    val loading: Boolean = false,
    val error: String? = null
)

class RegisterUserModel(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) : ViewModel() {

    var uiState by mutableStateOf(RegisterUiState())
        private set

    fun register(
        nombre: String,
        apellido: String,
        email: String,
        password: String,
        nivel: String,
        bio: String,
        onSuccess: () -> Unit
    ) {
        if (uiState.loading) return
        uiState = RegisterUiState(loading = true)

        auth.createUserWithEmailAndPassword(email.trim(), password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val uid = task.result?.user?.uid ?: auth.currentUser?.uid
                    if (uid == null) {
                        uiState = RegisterUiState(error = "Error interno: UID nulo")
                        return@addOnCompleteListener
                    }

                    val profile = UserProfile(
                        uid = uid,
                        nombre = nombre.trim(),
                        apellido = apellido.trim(),
                        email = email.trim(),
                        nivel = nivel,
                        bio = bio
                    )

                    // Guardar perfil en Firestore (colección "users", doc = uid)
                    firestore.collection("users").document(uid)
                        .set(profile)
                        .addOnCompleteListener { setTask ->
                            if (setTask.isSuccessful) {
                                // Opcional: enviar verificación de correo
                                uiState = RegisterUiState()
                                onSuccess()
                            } else {
                                uiState = RegisterUiState(error = setTask.exception?.localizedMessage ?: "Error guardando perfil")
                            }
                        }

                } else {
                    uiState = RegisterUiState(error = task.exception?.localizedMessage ?: "Error al crear la cuenta")
                }
            }
    }
}