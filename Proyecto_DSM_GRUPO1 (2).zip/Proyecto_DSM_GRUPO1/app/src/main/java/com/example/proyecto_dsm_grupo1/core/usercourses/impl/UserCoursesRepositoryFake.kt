package com.example.proyecto_dsm_grupo1.core.usercourses.impl

import com.example.proyecto_dsm_grupo1.core.models.Course
import com.example.proyecto_dsm_grupo1.core.models.UserCourse
import com.example.proyecto_dsm_grupo1.core.usercourses.UserCoursesRepository
import kotlinx.coroutines.delay
import java.util.concurrent.ConcurrentHashMap

class UserCoursesRepositoryFake : UserCoursesRepository {

    // uid -> lista en memoria
    private val store = ConcurrentHashMap<String, MutableList<UserCourse>>()

    override suspend fun getUserCourses(uid: String): List<UserCourse> {
        delay(200)
        return store[uid]?.toList().orEmpty()
    }

    override suspend fun addCourseToUser(uid: String, course: Course): UserCourse {
        delay(150)
        val list = store.getOrPut(uid) { mutableListOf() }
        // Evita duplicados
        list.firstOrNull { it.courseId == course.id }?.let { return it }

        val uc = UserCourse(
            courseId = course.id,
            title = course.title,
            teacher = course.teacher,
            level = course.level,
            rating = course.rating,
            progress = 0f,
            status = "pending",
            addedAt = System.currentTimeMillis()
        )
        list.add(uc)
        return uc
    }

    override suspend fun removeUserCourse(uid: String, courseId: String) {
        delay(120)
        store[uid]?.removeAll { it.courseId == courseId }
    }

    override suspend fun updateProgress(uid: String, courseId: String, progress: Float) {
        delay(120)
        val list = store[uid] ?: return
        val idx = list.indexOfFirst { it.courseId == courseId }
        if (idx >= 0) {
            val current = list[idx]
            list[idx] = current.copy(
                progress = progress.coerceIn(0f, 1f),
                status = when {
                    progress >= 1f -> "done"
                    progress > 0f  -> "in_progress"
                    else           -> "pending"
                }
            )
        }
    }
}
