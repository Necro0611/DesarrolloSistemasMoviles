package com.example.proyecto_dsm_grupo1.U_I.home

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.proyecto_dsm_grupo1.core.di.ServiceLocator
import com.example.proyecto_dsm_grupo1.core.usercourses.UserCoursesRepository
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

private const val TAG = "HomeViewModel"

data class CourseUI(
    val id: String,
    val title: String,
    val teacher: String,
    val level: String,
    val progress: Float,
    val rating: Float
)

data class HomeUiState(
    val loading: Boolean = true,
    val userName: String = "Usuario",
    val courses: List<CourseUI> = emptyList(),
    val recommendation: CourseUI? = null,
    val error: String? = null
)

class HomeViewModel(
    private val repo: UserCoursesRepository = ServiceLocator.userCoursesRepo,
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) : ViewModel() {

    var uiState by mutableStateOf(HomeUiState())
        private set

    private val authListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
        // Cuando cambie el usuario autenticado recargamos
        Log.d(TAG, "Auth state changed: ${firebaseAuth.currentUser?.uid}")
        load()
    }

    init {
        auth.addAuthStateListener(authListener)
        load()
    }

    override fun onCleared() {
        super.onCleared()
        try { auth.removeAuthStateListener(authListener) } catch (_: Exception) {}
    }

    private fun setState(reducer: (HomeUiState) -> HomeUiState) {
        uiState = reducer(uiState)
    }

    /**
     * Carga el nombre del usuario y sus cursos.
     * Usa userCoursesRepo.getUserCourses(uid) y lee users/{uid}.nombre para el nombre.
     */
    fun load() = viewModelScope.launch {
        setState { it.copy(loading = true, error = null) }

        val user = auth.currentUser
        val uid = user?.uid

        if (uid.isNullOrBlank()) {
            // Usuario no autenticado: dejar estado vacío pero quitar loader
            setState {
                it.copy(
                    loading = false,
                    userName = "Usuario",
                    courses = emptyList(),
                    recommendation = null
                )
            }
            Log.d(TAG, "No user authenticated - load finished")
            return@launch
        }

        try {
            // 1) leer nombre desde Firestore (si existe)
            val userDoc = try {
                firestore.collection("users").document(uid).get().await()
            } catch (e: Exception) {
                Log.w(TAG, "Error leyendo profile doc: ${e.localizedMessage}", e)
                null
            }

            val nombreFromDoc = userDoc?.getString("nombre")?.takeIf { it.isNotBlank() }
            val nameToShow = nombreFromDoc
                ?: user.displayName
                ?: user.email
                ?: "Usuario"

            // 2) obtener cursos del usuario desde el repo
            val userCourses = try {
                repo.getUserCourses(uid)
            } catch (e: Exception) {
                Log.e(TAG, "Error al obtener userCourses: ${e.localizedMessage}", e)
                emptyList()
            }

            // Mapear a CourseUI
            val mapped = userCourses.map {
                CourseUI(
                    id = it.courseId,
                    title = it.title,
                    teacher = it.teacher,
                    level = it.level,
                    progress = it.progress,
                    rating = it.rating
                )
            }

            setState {
                it.copy(
                    loading = false,
                    userName = nameToShow,
                    courses = mapped,
                    recommendation = null,
                    error = null
                )
            }
            Log.d(TAG, "Home loaded: user=$nameToShow courses=${mapped.size}")
        } catch (e: Exception) {
            Log.e(TAG, "load() failed", e)
            setState { it.copy(loading = false, error = e.localizedMessage ?: "Error cargando inicio") }
        }
    }
}