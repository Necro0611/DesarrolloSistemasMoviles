package com.example.proyecto_dsm_grupo1.U_I.profile

import android.util.Patterns
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import com.example.proyecto_dsm_grupo1.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterUserScreen(
    onRegisterOk: () -> Unit,                // navegar a HOME si es válido
    onGoogleRegisterClick: () -> Unit = {},  // preparado para conectar
    onTermsClick: () -> Unit = {},            // abrir TyC más adelante
    viewModel: RegisterUserModel = viewModel() // <- inyecta el ViewModel
) {
    // Colores iguales al Login
    val primaryGreen = Color(0xFF2DBE71)
    val lightGray    = Color(0xFFF3F5F4)
    val textGray     = Color(0xFF6B7280)

    // Estados
    var nombre by rememberSaveable { mutableStateOf("") }
    var apellido by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var confirm by rememberSaveable { mutableStateOf("") }
    var nivelExpanded by rememberSaveable { mutableStateOf(false) }
    var nivel by rememberSaveable { mutableStateOf("Selecciona tu nivel") }
    var bio by rememberSaveable { mutableStateOf("") }
    var termsChecked by rememberSaveable { mutableStateOf(false) }

    var passwordVisible by rememberSaveable { mutableStateOf(false) }
    var confirmVisible by rememberSaveable { mutableStateOf(false) }

    val niveles = listOf("Secundaria", "Pregrado", "Posgrado", "Diplomado", "Autodidacta")

    // Validaciones
    val emailValid = remember(email) { Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() }
    val passLenOk  = remember(password) { password.length >= 6 }
    val passMatch  = remember(password, confirm) { confirm.isNotBlank() && password == confirm }
    val nivelOk    = remember(nivel) { nivel in niveles }
    val nombreOk   = remember(nombre) { nombre.isNotBlank() }
    val apellidoOk = remember(apellido) { apellido.isNotBlank() }

    val allValid = nombreOk && apellidoOk && emailValid && passLenOk && passMatch && nivelOk && termsChecked

    val uiState = viewModel.uiState

    Box(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
    ) {
        // Fondo
        Image(
            painter = painterResource(id = R.drawable.screen),
            contentDescription = "Fondo",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Logo
            Image(
                painter = painterResource(id = R.drawable.logo_dsm_removebg_preview),
                contentDescription = "Logo",
                modifier = Modifier
                    .width(160.dp)
                    .padding(top = 8.dp, bottom = 6.dp)
            )

            // Título “Crear cuenta” centrado, más grande
            Text(
                "Crear cuenta",
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp, bottom = 12.dp),
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                color = primaryGreen
            )

            // Botón Google con fondo verde muy suave
            OutlinedButton(
                onClick = { onGoogleRegisterClick() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(24.dp),
                border = ButtonDefaults.outlinedButtonBorder.copy(
                    width = 1.dp,
                    brush = androidx.compose.ui.graphics.SolidColor(primaryGreen.copy(alpha = 0.6f))
                ),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = primaryGreen.copy(alpha = 0.12f), // verde suave/transparente
                    contentColor = primaryGreen
                )
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.flat_color_icons__google),
                        contentDescription = "Google",
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Registrarse con Google", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                }
            }

            // Separador “o continuar con”
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Divider(modifier = Modifier.weight(1f), color = lightGray)
                Text("  o continuar con  ", color = textGray, style = MaterialTheme.typography.labelLarge)
                Divider(modifier = Modifier.weight(1f), color = lightGray)
            }

            // ======== Campos ========
            LabeledField("Nombre") {
                OutlinedTextField(
                    value = nombre,
                    onValueChange = { nombre = it },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Ingresa tu nombre") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = primaryGreen,
                        unfocusedBorderColor = primaryGreen.copy(alpha = 0.5f),
                        cursorColor = primaryGreen
                    )
                )
            }

            LabeledField("Apellido") {
                OutlinedTextField(
                    value = apellido,
                    onValueChange = { apellido = it },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Ingresa tu apellido") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = primaryGreen,
                        unfocusedBorderColor = primaryGreen.copy(alpha = 0.5f),
                        cursorColor = primaryGreen
                    )
                )
            }

            LabeledField("Correo Electrónico") {
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Ingresa tu correo") },
                    isError = email.isNotBlank() && !emailValid,
                    supportingText = {
                        if (email.isNotBlank() && !emailValid) {
                            Text("Correo inválido", color = MaterialTheme.colorScheme.error)
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = primaryGreen,
                        unfocusedBorderColor = primaryGreen.copy(alpha = 0.5f),
                        cursorColor = primaryGreen
                    )
                )
            }

            LabeledField("Contraseña") {
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        Text(if (passwordVisible) "🙈" else "👁️", modifier = Modifier.clickable { passwordVisible = !passwordVisible })
                    },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Ingresa tu contraseña") },
                    isError = password.isNotBlank() && !passLenOk,
                    supportingText = {
                        if (password.isNotBlank() && !passLenOk) {
                            Text("Mínimo 6 caracteres", color = MaterialTheme.colorScheme.error)
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = primaryGreen,
                        unfocusedBorderColor = primaryGreen.copy(alpha = 0.5f),
                        cursorColor = primaryGreen
                    )
                )
            }

            LabeledField("Confirmar contraseña") {
                OutlinedTextField(
                    value = confirm,
                    onValueChange = { confirm = it },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    visualTransformation = if (confirmVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        Text(if (confirmVisible) "🙈" else "👁️", modifier = Modifier.clickable { confirmVisible = !confirmVisible })
                    },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Repite tu contraseña") },
                    isError = confirm.isNotBlank() && !passMatch,
                    supportingText = {
                        if (confirm.isNotBlank() && !passMatch) {
                            Text("Las contraseñas no coinciden", color = MaterialTheme.colorScheme.error)
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = primaryGreen,
                        unfocusedBorderColor = primaryGreen.copy(alpha = 0.5f),
                        cursorColor = primaryGreen
                    )
                )
            }

            // Nivel educativo (dropdown)
            LabeledField("Nivel educativo") {
                ExposedDropdownMenuBox(
                    expanded = nivelExpanded,
                    onExpandedChange = { nivelExpanded = !nivelExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = nivel,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = nivelExpanded) },
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth(),
                        isError = !nivelOk,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = primaryGreen,
                            unfocusedBorderColor = primaryGreen.copy(alpha = 0.5f),
                            cursorColor = primaryGreen
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = nivelExpanded,
                        onDismissRequest = { nivelExpanded = false }
                    ) {
                        niveles.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option) },
                                onClick = {
                                    nivel = option
                                    nivelExpanded = false
                                }
                            )
                        }
                    }
                }
            }

            // Bio (multilínea más grande)
            LabeledField("Bio") {
                OutlinedTextField(
                    value = bio,
                    onValueChange = { bio = it },
                    placeholder = { Text("Cuéntanos sobre ti...") },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp),
                    minLines = 4,
                    maxLines = 6,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = primaryGreen,
                        unfocusedBorderColor = primaryGreen.copy(alpha = 0.5f),
                        cursorColor = primaryGreen
                    )
                )
            }

            // Términos y condiciones
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 6.dp)
            ) {
                Checkbox(checked = termsChecked, onCheckedChange = { termsChecked = it })
                Spacer(Modifier.width(6.dp))
                Text("Acepto los ")
                Text(
                    text = "Términos y condiciones",
                    color = primaryGreen,
                    modifier = Modifier.clickable { onTermsClick() }
                )
            }

            // Botón Registrar (habilitado solo si allValid)
            Button(
                onClick = { if (allValid)  {
                    viewModel.register(
                        nombre = nombre,
                        apellido = apellido,
                        email = email,
                        password = password,
                        nivel = nivel,
                        bio = bio,
                        onSuccess = { onRegisterOk() }
                    )
                } },
                enabled = allValid && !uiState.loading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = primaryGreen,
                    contentColor = Color.White,
                    disabledContainerColor = primaryGreen.copy(alpha = 0.4f)
                )
            ) {
                Text("Registrar", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }

            if (uiState.error != null) {
                AlertDialog(
                    onDismissRequest = { /* limpiar error si quieres */ },
                    confirmButton = {
                        TextButton(onClick = { /* limpiar error */ /* aquí podrías resetear uiState usando otra función si la agregas */ }) {
                            Text("OK")
                        }
                    },
                    title = { Text("Registro fallido") },
                    text = { Text(uiState.error ?: "") }
                )
            }

            Spacer(Modifier.height(18.dp))

            // Volver a Iniciar sesión (solo visual)
            TextButton(onClick = { /* nav back a login (opcional) */ }) {
                Row {
                    Text("¿Ya tienes una cuenta?  ", color = textGray)
                    Text("Iniciar Sesión", fontWeight = FontWeight.SemiBold, color = primaryGreen)
                }
            }

            Spacer(Modifier.height(28.dp))
        }
    }
}

/* --------- Helper visual para etiqueta + campo --------- */
@Composable
private fun LabeledField(
    label: String,
    content: @Composable () -> Unit
) {
    Column(Modifier.fillMaxWidth()) {
        Text(
            label,
            style = MaterialTheme.typography.labelLarge.copy(color = Color(0xFF2F3B45)),
            modifier = Modifier.padding(bottom = 6.dp, top = 6.dp)
        )
        content()
        Spacer(Modifier.height(8.dp))
    }
}
