package com.example.proyecto_dsm_grupo1.U_I.catalog

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.proyecto_dsm_grupo1.core.catalog.CatalogRepository
import com.example.proyecto_dsm_grupo1.core.di.ServiceLocator
import com.example.proyecto_dsm_grupo1.core.models.Course
import kotlinx.coroutines.launch
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class CatalogUiState(
    val loading: Boolean = true,
    val allCourses: List<Course> = emptyList(),
    val filtered: List<Course> = emptyList(),
    val query: String = "",
    val selectedCategory: String? = null,
    val categories: List<String> = emptyList()
)

class CatalogViewModel(
    private val repo: CatalogRepository = ServiceLocator.catalogRepo
) : ViewModel() {

    // ← IMPORTANTE: usar mutableStateOf para que Compose se recomponga
    var uiState by mutableStateOf(CatalogUiState())
        private set

    init { load() }

    private fun setState(reducer: (CatalogUiState) -> CatalogUiState) {
        uiState = reducer(uiState)
    }

    private fun load() = viewModelScope.launch {
        setState { it.copy(loading = true) }
        val courses = repo.getCoursesCatalog()
        val cats = courses.flatMap { it.tags }.distinct()
        setState {
            it.copy(
                loading = false,
                allCourses = courses,
                filtered = courses,
                categories = cats
            )
        }
    }

    fun onQueryChange(q: String) {
        setState { it.copy(query = q) }
        applyFilters()
    }

    fun onToggleCategory(cat: String) {
        setState { it.copy(selectedCategory = if (it.selectedCategory == cat) null else cat) }
        applyFilters()
    }

    private fun applyFilters() {
        val s = uiState
        val q = s.query.trim().lowercase()
        val cat = s.selectedCategory
        val base = s.allCourses.asSequence()
            .filter { c ->
                if (q.isBlank()) true else {
                    c.title.lowercase().contains(q) ||
                            c.teacher.lowercase().contains(q) ||
                            c.description.lowercase().contains(q)
                }
            }
            .filter { c -> cat == null || c.tags.contains(cat) }
            .toList()
        setState { it.copy(filtered = base) }
    }
}
