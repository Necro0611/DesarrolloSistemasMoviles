package com.example.proyecto_dsm_grupo1.core.nav

object Routes {
    const val LOGIN = "login"
    const val REGISTER = "register"
    const val HOME = "home"
    const val SETTINGS = "settings"
    const val EDIT_PROFILE = "edit_profile"

    const val CATALOG = "catalog"
    const val COURSE_DETAIL = "course_detail/{courseId}"
    const val CHATBOT_LIST = "chatbot_list"
    const val CHATBOT_CHAT = "chatbot_chat/{conversationId}"
}
