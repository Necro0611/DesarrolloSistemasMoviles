package com.example.proyecto_dsm_grupo1.U_I.chatbot

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.proyecto_dsm_grupo1.U_I.chatbot.components.ChatComposer
import com.example.proyecto_dsm_grupo1.U_I.chatbot.components.MessageBubble
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

// >>> VERDE DEL CHATBOT (cámbialo si quieres otro tono)
private val ChatGreen = Color(0xFF22C55E)

data class ChatConversationUi(
    val id: String = UUID.randomUUID().toString(),
    val titulo: String,
    val contextoAcademico: String,
    val ultimaInteraccion: Date,
    val estado: String = "activa",
    val ultimoMensajePreview: String
)
enum class MessageAuthor { USER, BOT }
data class ChatMessageUi(
    val id: String = UUID.randomUUID().toString(),
    val conversationId: String,
    val author: MessageAuthor,
    val contenido: String,
    val timestamp: Date = Date()
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatbotListScreen(
    onOpenConversation: (String) -> Unit,
    onCreateNewConversation: () -> Unit,
    onBack: () -> Unit = { }
) {
    var query by remember { mutableStateOf(TextFieldValue("")) }
    val formatter = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }

    fun nowMinus(minutes: Int = 0, hours: Int = 0, days: Int = 0): Date {
        val ms = System.currentTimeMillis() -
                minutes * 60_000L - hours * 3_600_000L - days * 86_400_000L
        return Date(ms)
    }

    val base = remember {
        listOf(
            ChatConversationUi(
                titulo = "Cálculo Diferencial",
                contextoAcademico = "Matemáticas I",
                ultimaInteraccion = nowMinus(minutes = 5),
                ultimoMensajePreview = "Explícame la regla de la cadena con un ejemplo"
            ),
            ChatConversationUi(
                titulo = "Algoritmos y Estructuras",
                contextoAcademico = "CS-201",
                ultimaInteraccion = nowMinus(hours = 2),
                ultimoMensajePreview = "¿Cuál es la complejidad de merge sort?"
            ),
            ChatConversationUi(
                titulo = "Machine Learning",
                contextoAcademico = "IA",
                ultimaInteraccion = nowMinus(days = 1),
                ultimoMensajePreview = "Resume 'overfitting' en 3 líneas"
            )
        ).map { it.copy(id = UUID.randomUUID().toString()) }
    }

    val filtered = remember(query.text, base) {
        if (query.text.isBlank()) base
        else {
            val q = query.text.trim().lowercase(Locale.getDefault())
            base.filter {
                it.titulo.lowercase(Locale.getDefault()).contains(q) ||
                        it.contextoAcademico.lowercase(Locale.getDefault()).contains(q) ||
                        it.ultimoMensajePreview.lowercase(Locale.getDefault()).contains(q)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "Atrás",
                            tint = Color.White)
                    }
                },
                title = { Text("Chat IA", color = Color.White) },
                actions = {
                    IconButton(onClick = onCreateNewConversation) {
                        Icon(Icons.Outlined.Add, contentDescription = "Nueva conversación",
                            tint = Color.White)
                    }
                    IconButton(onClick = { /* más opciones futuras */ }) {
                        Icon(Icons.Outlined.MoreVert, contentDescription = "Más",
                            tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ChatGreen,
                    scrolledContainerColor = ChatGreen
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar conversación o tema") },
                singleLine = true,
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { /* noop */ })
            )

            Spacer(Modifier.height(12.dp))

            Text(
                text = "Conversaciones",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filtered, key = { it.id }) { conv ->
                    ConversationItem(
                        conversation = conv,
                        subtitle = "${conv.contextoAcademico} • ${formatter.format(conv.ultimaInteraccion)}",
                        onClick = { onOpenConversation(conv.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ConversationItem(
    conversation: ChatConversationUi,
    subtitle: String,
    onClick: () -> Unit
) {
    ElevatedCard(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(ChatGreen.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    conversation.titulo.take(1).uppercase(),
                    style = MaterialTheme.typography.titleMedium
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    conversation.titulo,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    conversation.ultimoMensajePreview,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatbotChatScreen(
    conversationId: String,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val list = remember { mutableStateListOf<ChatMessageUi>() }

    LaunchedEffect(conversationId) {
        list.clear()
        list.addAll(
            listOf(
                ChatMessageUi(
                    conversationId = conversationId,
                    author = MessageAuthor.BOT,
                    contenido = "¡Hola! Soy tu tutor IA. ¿En qué tema quieres profundizar hoy?"
                ),
                ChatMessageUi(
                    conversationId = conversationId,
                    author = MessageAuthor.USER,
                    contenido = "Estoy con derivadas, específicamente la regla de la cadena."
                ),
                ChatMessageUi(
                    conversationId = conversationId,
                    author = MessageAuthor.BOT,
                    contenido = "La regla de la cadena se aplica a composiciones f(g(x)). ¿Quieres una explicación o un ejemplo paso a paso?"
                )
            )
        )
    }

    var input by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "Atrás", tint = Color.White)
                    }
                },
                title = { Text("Conversación", color = Color.White) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ChatGreen,
                    scrolledContainerColor = ChatGreen
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(list, key = { it.id }) { msg ->
                    MessageBubble(
                        text = msg.contenido,
                        isMine = msg.author == MessageAuthor.USER,
                        timestamp = msg.timestamp
                    )
                }
                item { Spacer(Modifier.height(4.dp)) }
            }

            ChatComposer(
                value = input,
                onValueChange = { input = it },
                onSend = {
                    if (input.isNotBlank()) {
                        list.add(
                            ChatMessageUi(
                                conversationId = conversationId,
                                author = MessageAuthor.USER,
                                contenido = input.trim()
                            )
                        )
                        input = ""

                        scope.launch {
                            kotlinx.coroutines.delay(600)
                            list.add(
                                ChatMessageUi(
                                    conversationId = conversationId,
                                    author = MessageAuthor.BOT,
                                    contenido = "Respuesta simulada 🤖: buen punto, ahora aplica la regla y simplifica."
                                )
                            )
                        }
                    }
                }
            )
        }
    }
}
