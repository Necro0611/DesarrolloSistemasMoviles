package com.example.proyecto_dsm_grupo1.U_I.course

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.proyecto_dsm_grupo1.core.catalog.CatalogRepository
import com.example.proyecto_dsm_grupo1.core.di.ServiceLocator
import com.example.proyecto_dsm_grupo1.core.models.Course
import com.example.proyecto_dsm_grupo1.core.usercourses.UserCoursesRepository
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

private const val TAG = "CourseDetailVM"

data class CourseDetailUiState(
    val loading: Boolean = true,
    val course: Course? = null,
    val adding: Boolean = false,        // mientras se agrega el curso al usuario
    val added: Boolean = false,
    val error: String? = null
)

class CourseDetailViewModel(
    private val catalog: CatalogRepository = ServiceLocator.catalogRepo,
    private val userRepo: UserCoursesRepository = ServiceLocator.userCoursesRepo,
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) : ViewModel() {

    var uiState by mutableStateOf(CourseDetailUiState())
        private set

    private fun setState(reducer: (CourseDetailUiState) -> CourseDetailUiState) {
        uiState = reducer(uiState)
    }

    /**
     * Carga el curso por id. Si el repo no provee getCourseById, se obtiene todo el catálogo y se filtra.
     */
    fun load(courseId: String) = viewModelScope.launch {
        setState { it.copy(loading = true, error = null, added = false) }
        try {
            val all = catalog.getCoursesCatalog()
            val c = all.firstOrNull { it.id == courseId }

            // comprobar si el usuario ya tiene el curso
            val uid = auth.currentUser?.uid
            var isAdded = false
            if (!uid.isNullOrBlank()) {
                try {
                    val userCourses = userRepo.getUserCourses(uid)
                    isAdded = userCourses.any { it.courseId == courseId }
                } catch (e: Exception) {
                    Log.w(TAG, "No se pudo comprobar userCourses: ${e.localizedMessage}", e)
                }
            }

            setState {
                it.copy(
                    loading = false,
                    course = c,
                    added = isAdded,
                    error = if (c == null) "Curso no encontrado" else null
                )
            }
        } catch (e: Exception) {
            setState { it.copy(loading = false, error = e.localizedMessage ?: "Error cargando curso") }
        }
    }

    /**
     * Agrega el curso al usuario autenticado. Llama onDone() si tuvo éxito.
     * Si no hay usuario autenticado, establece error.
     */
    fun addToUser(onDone: () -> Unit) = viewModelScope.launch {
        val course = uiState.course
        if (course == null) {
            setState { it.copy(error = "No hay curso cargado") }
            return@launch
        }

        val uid = auth.currentUser?.uid
        if (uid.isNullOrBlank()) {
            setState { it.copy(error = "Usuario no autenticado") }
            return@launch
        }

        setState { it.copy(adding = true, error = null) }

        try {
            val userCourse = userRepo.addCourseToUser(uid, course)
            Log.d(TAG, "Curso agregado OK: ${userCourse.courseId} para uid=$uid")
            setState { it.copy(adding = false, added = true) }
            onDone()
        } catch (e: Exception) {
            Log.e(TAG, "Error agregando curso al usuario", e)
            setState { it.copy(adding = false, error = e.localizedMessage ?: "Error agregando curso") }
        }
    }
}