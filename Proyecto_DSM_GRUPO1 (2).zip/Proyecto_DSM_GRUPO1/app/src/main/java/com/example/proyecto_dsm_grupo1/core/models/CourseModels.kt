package com.example.proyecto_dsm_grupo1.core.models

data class Course(
    val id: String,
    val title: String,
    val teacher: String,
    val level: String,               // "Principiante" | "Intermedio" | "Avanzado"
    val rating: Float,               // 0..5
    val imageUrl: String? = null,
    val description: String = "",
    val tags: List<String> = emptyList()
)

data class UserCourse(
    val courseId: String,
    val title: String,
    val teacher: String,
    val level: String,
    val rating: Float,
    val progress: Float,             // 0..1
    val status: String,              // "pending"|"in_progress"|"done"
    val addedAt: Long
)
