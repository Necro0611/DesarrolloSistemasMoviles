package com.example.proyecto_dsm_grupo1.core.nav

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.proyecto_dsm_grupo1.U_I.auth.LoginScreen
import com.example.proyecto_dsm_grupo1.U_I.catalog.CatalogScreen
import com.example.proyecto_dsm_grupo1.U_I.course.CourseDetailScreen
import com.example.proyecto_dsm_grupo1.U_I.home.HomeScreen
import com.example.proyecto_dsm_grupo1.U_I.profile.EditProfileScreen
import com.example.proyecto_dsm_grupo1.U_I.profile.RegisterUserScreen
import com.example.proyecto_dsm_grupo1.U_I.profile.SettingsScreen

// Chatbot UI (solo interfaz)
import com.example.proyecto_dsm_grupo1.U_I.chatbot.ChatbotChatScreen
import com.example.proyecto_dsm_grupo1.U_I.chatbot.ChatbotListScreen

@Composable
fun AppNavHost(nav: NavHostController) {
    NavHost(navController = nav, startDestination = Routes.LOGIN) {

        composable(Routes.LOGIN) {
            LoginScreen(
                onLoginOk = {
                    nav.navigate(Routes.HOME) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                },
                onRegisterClick = { nav.navigate(Routes.REGISTER) },
                onForgotClick = { /* TODO */ },
                onGoogleClick = { /* TODO */ }
            )
        }

        composable(Routes.REGISTER) {
            RegisterUserScreen(
                onRegisterOk = {
                    nav.navigate(Routes.HOME) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                }
            )
        }

        // ==========================
        // HOME con botón flotante IA
        // ==========================
        composable(Routes.HOME) {
            HomeWithChatButton(
                onOpenSettings = { nav.navigate(Routes.SETTINGS) },
                onOpenCatalog  = { nav.navigate(Routes.CATALOG) },
                onOpenChatbot  = { nav.navigate(Routes.CHATBOT_LIST) }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                onBack = { nav.popBackStack() },
                onPersonalInfo = { nav.navigate(Routes.EDIT_PROFILE) },
                onAiSummaries = { /* También podrías nav a CHATBOT_LIST aquí */ },
                onExportData = { /* TODO */ },
                onPomodoro = { /* TODO */ },
                onNotificationsPerms = { /* TODO */ },
                onLanguage = { /* TODO */ },
                onHelpSupport = { /* TODO */ },
                onLogout = {
                    nav.navigate(Routes.LOGIN) {
                        popUpTo(Routes.HOME) { inclusive = true }
                    }
                }
            )
        }

        // Catálogo
        composable(Routes.CATALOG) {
            CatalogScreen(
                onBack = { nav.popBackStack() },
                onCourseClick = { id -> nav.navigate("course_detail/$id") }
            )
        }

        // Detalle de curso
        composable(
            route = Routes.COURSE_DETAIL,
            arguments = listOf(navArgument("courseId") { type = NavType.StringType })
        ) { backStack ->
            val id = backStack.arguments?.getString("courseId") ?: return@composable
            CourseDetailScreen(
                courseId = id,
                onBack = { nav.popBackStack() },
                onAddedGoBack = {
                    nav.popBackStack() // vuelve al catálogo
                    nav.popBackStack() // y luego a Home
                }
            )
        }

        composable(Routes.EDIT_PROFILE) {
            EditProfileScreen(
                onBack = { nav.popBackStack() },
                onSaved = { nav.popBackStack() }
            )
        }

        // ================================
        // Chatbot (solo interfaz)
        // ================================
        composable(Routes.CHATBOT_LIST) {
            ChatbotListScreen(
                onOpenConversation = { id ->
                    nav.navigate("chatbot_chat/$id")
                },
                onCreateNewConversation = {
                    val newId = java.util.UUID.randomUUID().toString()
                    nav.navigate("chatbot_chat/$newId")
                },
                onBack = { nav.popBackStack() } // botón atrás en la lista
            )
        }

        composable(
            route = Routes.CHATBOT_CHAT,
            arguments = listOf(navArgument("conversationId") { type = NavType.StringType })
        ) { backStackEntry ->
            val convId = backStackEntry.arguments?.getString("conversationId") ?: ""
            ChatbotChatScreen(
                conversationId = convId,
                onBack = { nav.popBackStack() }
            )
        }
    }
}

/* ---------------------------------------------------------
 * Wrapper que superpone un FAB circular "IA" sobre tu Home
 * --------------------------------------------------------- */
@Composable
private fun HomeWithChatButton(
    onOpenSettings: () -> Unit,
    onOpenCatalog: () -> Unit,
    onOpenChatbot: () -> Unit
) {
    Box {
        // Tu Home original (sin modificaciones)
        HomeScreen(
            onNotificationsClick = { /* opcional */ },
            onProfileClick = onOpenSettings,
            onAddTopicClick = onOpenCatalog
        )

        // FAB pequeño circular sobre la esquina inferior derecha
        SmallFloatingActionButton(
            onClick = onOpenChatbot,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                // padding para quedar por encima del BottomBar (ajusta si tu barra es más alta)
                .padding(end = 20.dp, bottom = 84.dp),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            shape = CircleShape
        ) {
            Icon(
                imageVector = Icons.Outlined.Chat, // ícono seguro disponible
                contentDescription = "Chat IA"
            )
        }
    }
}
