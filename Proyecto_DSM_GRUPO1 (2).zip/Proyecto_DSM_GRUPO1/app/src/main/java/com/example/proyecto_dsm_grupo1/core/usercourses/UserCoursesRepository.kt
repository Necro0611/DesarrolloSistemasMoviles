package com.example.proyecto_dsm_grupo1.core.usercourses

import com.example.proyecto_dsm_grupo1.core.models.Course
import com.example.proyecto_dsm_grupo1.core.models.UserCourse

interface UserCoursesRepository {
    suspend fun getUserCourses(uid: String): List<UserCourse>
    suspend fun addCourseToUser(uid: String, course: Course): UserCourse
    suspend fun removeUserCourse(uid: String, courseId: String)
    suspend fun updateProgress(uid: String, courseId: String, progress: Float)
}
