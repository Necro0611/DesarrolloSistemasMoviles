package com.example.proyecto_dsm_grupo1.U_I.profile

data class UserProfile(
    val uid: String = "",
    val nombre: String = "",
    val apellido: String = "",
    val email: String = "",
    val nivel: String = "",
    val bio: String = ""
)
