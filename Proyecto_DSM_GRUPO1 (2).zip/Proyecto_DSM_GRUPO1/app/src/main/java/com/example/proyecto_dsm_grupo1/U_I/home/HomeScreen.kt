package com.example.proyecto_dsm_grupo1.U_I.home

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CellTower
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PlayCircle
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun HomeScreen(
    onNotificationsClick: () -> Unit = {},
    onProfileClick: () -> Unit = {},
    onAddTopicClick: () -> Unit = {},   // ← nuevo: navegar a catálogo
    vm: HomeViewModel = viewModel()
) {
    val state = vm.uiState
    val containerPadding = 16.dp
    val headerHeight = 150.dp

    Scaffold(
        bottomBar = { BottomNavBar(onProfileClick) }
    ) { innerPadding ->

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Fondo superior
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(headerHeight)
                    .background(
                        brush = Brush.verticalGradient(
                            listOf(Color(0xFF79C78C), Color(0xFF5DBB7A))
                        )
                    )
            )

            // Contenido
            if (state.loading) {
                // Loader simple (puedes poner skeletons si quieres)
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color(0xFF69C080))
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 96.dp)
                ) {
                    // Header con saludo + campana
                    item {
                        TopGreeting(
                            name = state.userName,
                            onNotificationsClick = onNotificationsClick,
                            modifier = Modifier.padding(horizontal = containerPadding, vertical = 12.dp)
                        )
                    }

                    // Recomendación: solo si existe
                    state.recommendation?.let { rec ->
                        item {
                            RecommendationCard(
                                modifier = Modifier.padding(horizontal = containerPadding),
                                onClick = { /* TODO: abrir detalle rec */ }
                            )
                        }
                    }

                    // Si NO hay cursos → estado vacío + botón Agregar tema
                    if (state.courses.isEmpty()) {
                        item {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "Aún no tienes cursos pendientes",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.SemiBold
                                ),
                                modifier = Modifier.padding(horizontal = containerPadding)
                            )
                        }
                        item {
                            AddTopicCard(
                                modifier = Modifier
                                    .padding(horizontal = containerPadding, vertical = 12.dp)
                                    .clickable { onAddTopicClick() } // ← navega a catálogo
                            )
                        }
                    } else {
                        // Título: Cursos pendientes
                        item {
                            Text(
                                text = "Cursos Pendientes",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onBackground
                                ),
                                modifier = Modifier.padding(horizontal = containerPadding, vertical = 12.dp)
                            )
                        }

                        items(state.courses) { course ->
                            CourseCard(
                                course = course,
                                modifier = Modifier
                                    .padding(horizontal = containerPadding, vertical = 6.dp)
                                    .clickable { /* TODO: ir a detalle */ }
                            )
                        }

                        // Agregar tema (siempre visible)
                        item {
                            AddTopicCard(
                                modifier = Modifier
                                    .padding(horizontal = containerPadding, vertical = 8.dp)
                                    .clickable { onAddTopicClick() }
                            )
                        }
                    }
                }
            }
        }
    }
}

/* ================== Componentes UI (sin cambios visuales) ================== */

@Composable
private fun TopGreeting(
    name: String,
    onNotificationsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Color(0xFFF2F5F4)),
            contentAlignment = Alignment.Center
        ) { Text("👋", fontSize = 20.sp) }

        Spacer(Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "Hola $name",
                style = MaterialTheme.typography.titleMedium.copy(
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold
                )
            )
            Text(
                text = "Tu progreso de estudio de esta semana",
                style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFEAF7EE)),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        IconButton(
            onClick = onNotificationsClick,
            colors = IconButtonDefaults.iconButtonColors(contentColor = Color.White)
        ) {
            Icon(Icons.Outlined.CellTower, contentDescription = "Notificaciones")
        }
    }
}

@Composable
private fun RecommendationCard(
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {}
) {
    ElevatedCard(
        modifier = modifier
            .padding(top = 4.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Recomendaciones de estudio",
                style = MaterialTheme.typography.labelLarge.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Programación I",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Progreso Actual",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            ProgressBarWithPercent(target = 0.10f)
                        }
                        Spacer(Modifier.width(12.dp))
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(Color(0xFFF2F5F4)),
                            contentAlignment = Alignment.Center
                        ) { Text("🖼️", fontSize = 18.sp) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProgressBarWithPercent(target: Float, modifier: Modifier = Modifier) {
    val animated = animateFloatAsState(
        targetValue = target.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing),
        label = "progressAnim"
    ).value

    Spacer(Modifier.height(8.dp))
    LinearProgressIndicator(
        progress = animated,
        modifier = modifier
            .fillMaxWidth()
            .height(10.dp)
            .clip(RoundedCornerShape(10.dp)),
        trackColor = Color(0xFFE9ECEF),
        color = Color(0xFF69C080)
    )
    Spacer(Modifier.height(6.dp))
    Text(
        text = "${(target * 100).toInt()}%",
        style = MaterialTheme.typography.labelMedium.copy(
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    )
}

@Composable
private fun CourseCard(
    course: CourseUI,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.5.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = Color.White)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFFF2F5F4)),
                contentAlignment = Alignment.Center
            ) { Text("🖼️", fontSize = 18.sp) }

            Spacer(Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = course.title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                )

                Spacer(Modifier.height(4.dp))

                Text(
                    text = "Progreso ${(course.progress * 100).toInt()}%",
                    style = MaterialTheme.typography.labelLarge
                )

                Spacer(Modifier.height(8.dp))

                val animatedProg = animateFloatAsState(
                    targetValue = course.progress,
                    animationSpec = tween(800),
                    label = "courseProgress"
                ).value

                LinearProgressIndicator(
                    progress = animatedProg,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    trackColor = Color(0xFFE9ECEF),
                    color = Color(0xFF69C080)
                )

                Spacer(Modifier.height(8.dp))

                val star = "★"
                Text(
                    text = "$star ${course.rating} • Por ${course.teacher} • ${course.level}",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun AddTopicCard(modifier: Modifier = Modifier) {
    ElevatedCard(
        shape = RoundedCornerShape(20.dp),
        modifier = modifier,
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = Color.White)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Text(
                text = "Agregar tema",
                style = MaterialTheme.typography.bodyLarge.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )
        }
    }
}

/* =================== Bottom Navigation (Perfil → Settings) =================== */

@Composable
private fun BottomNavBar(
    onProfileClick: () -> Unit = {}
) {
    NavigationBar(containerColor = Color.White, tonalElevation = 10.dp) {
        NavigationBarItem(
            selected = true,
            onClick = { /* Home */ },
            icon = { Icon(Icons.Outlined.Home, contentDescription = "Inicio") },
            label = { Text("Inicio") }
        )
        NavigationBarItem(
            selected = false,
            onClick = { /* Buscar */ },
            icon = { Icon(Icons.Outlined.Search, contentDescription = "Buscar") },
            label = { Text("Buscar") }
        )
        NavigationBarItem(
            selected = false,
            onClick = { /* Progreso */ },
            icon = { Icon(Icons.Outlined.PlayCircle, contentDescription = "Progreso") },
            label = { Text("Progreso") }
        )
        NavigationBarItem(
            selected = false,
            onClick = { onProfileClick() },
            icon = { Icon(Icons.Outlined.Person, contentDescription = "Perfil") },
            label = { Text("Perfil") }
        )
    }
}
