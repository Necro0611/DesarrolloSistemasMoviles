package com.example.proyecto_dsm_grupo1.U_I.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.proyecto_dsm_grupo1.R
import androidx.compose.foundation.text.KeyboardOptions

@Composable
fun LoginScreen(
    onLoginOk: () -> Unit,
    onRegisterClick: () -> Unit,
    onForgotClick: () -> Unit,
    onGoogleClick: () -> Unit,
    vm: LoginViewModel = LoginViewModel()
) {
    // Colores de referencia (mantengo tus valores actuales)
    val primaryGreen = Color(0xFF2DBE71)
    val lightGray = Color(0xFFF3F5F4)
    val textGray = Color(0xFF6B7280)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
    ) {
        // Fondo
        Image(
            painter = painterResource(id = R.drawable.screen),
            contentDescription = "Fondo",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .wrapContentHeight()
                .align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Logo
            Image(
                painter = painterResource(id = R.drawable.logo_dsm_removebg_preview),
                contentDescription = "Logo StudySprint",
                modifier = Modifier
                    .width(220.dp)
                    .padding(bottom = 24.dp)
            )

            var email by rememberSaveable { mutableStateOf("") }
            var password by rememberSaveable { mutableStateOf("") }
            var passwordVisible by rememberSaveable { mutableStateOf(false) }

            // Campo: Correo
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                placeholder = { Text("Correo") },
                leadingIcon = { Text("✉️", fontSize = 18.sp) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = primaryGreen,
                    unfocusedBorderColor = primaryGreen.copy(alpha = 0.5f),
                    cursorColor = primaryGreen
                )
            )

            Spacer(Modifier.height(12.dp))

            // Campo: Contraseña (emoji y toggle 👁️/🙈)
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                placeholder = { Text("Contraseña") },
                leadingIcon = { Text("🔒", fontSize = 18.sp) },
                trailingIcon = {
                    Text(
                        text = if (passwordVisible) "🙈" else "👁️",
                        fontSize = 18.sp,
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .clickable { passwordVisible = !passwordVisible }
                    )
                },
                singleLine = true,
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = primaryGreen,
                    unfocusedBorderColor = primaryGreen.copy(alpha = 0.5f),
                    cursorColor = primaryGreen
                )
            )

            // Olvidaste tu contraseña
            Text(
                text = "¿Olvidaste tu contraseña?",
                color = textGray,
                fontSize = 13.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp, bottom = 8.dp)
                    .clickable { onForgotClick() },
                textAlign = TextAlign.Center
            )

            // Botón principal: ahora llama al ViewModel
            Button(
                onClick = { vm.login(email, password, onLoginOk) },
                enabled = email.isNotBlank() && password.isNotBlank() && !vm.uiState.loading,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = primaryGreen,
                    contentColor = Color.White
                )
            ) {
                Text(
                    if (vm.uiState.loading) "Ingresando..." else "Iniciar Sesión",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            // Separador "o"
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
            ) {
                Divider(modifier = Modifier.weight(1f), color = lightGray)
                Box(
                    modifier = Modifier
                        .padding(horizontal = 12.dp)
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(lightGray),
                    contentAlignment = Alignment.Center
                ) {
                    Text("o", color = textGray, fontSize = 14.sp)
                }
                Divider(modifier = Modifier.weight(1f), color = lightGray)
            }

            // Botón Google
            OutlinedButton(
                onClick = { onGoogleClick() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.flat_color_icons__google),
                        contentDescription = "Google",
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Iniciar Sesión con Google", color = Color(0xFF1F2937), fontSize = 15.sp)
                }
            }

            // Registro
            Spacer(Modifier.height(16.dp))
            val annotated = buildAnnotatedString {
                withStyle(style = SpanStyle(color = textGray)) { append("¿No tienes una cuenta?, ") }
                withStyle(style = SpanStyle(color = primaryGreen, fontWeight = FontWeight.SemiBold)) { append("Regístrate aquí") }
            }
            Text(
                text = annotated,
                fontSize = 13.sp,
                modifier = Modifier.clickable { onRegisterClick() }
            )

            // (Opcional) Mostrar error de login si ocurre
            vm.uiState.error?.let { msg ->
                Spacer(Modifier.height(8.dp))
                Text(msg, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}

