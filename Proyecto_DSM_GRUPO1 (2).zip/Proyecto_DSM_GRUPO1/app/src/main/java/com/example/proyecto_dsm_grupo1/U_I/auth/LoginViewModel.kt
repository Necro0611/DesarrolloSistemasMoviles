package com.example.proyecto_dsm_grupo1.U_I.auth

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth

data class LoginUiState(
    val loading: Boolean = false,
    val error: String? = null
)

class LoginViewModel(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) : ViewModel() {

    var uiState by mutableStateOf(LoginUiState())
        private set

    fun login(email: String, password: String, onSuccess: () -> Unit) {
        if (uiState.loading) return
        uiState = LoginUiState(loading = true)
        auth.signInWithEmailAndPassword(email.trim(), password)
            .addOnCompleteListener { task ->
                uiState = if (task.isSuccessful) {
                    onSuccess(); LoginUiState()
                } else {
                    LoginUiState(error = task.exception?.localizedMessage ?: "Error al iniciar sesión")
                }
            }
    }
}
