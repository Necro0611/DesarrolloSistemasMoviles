package com.example.proyecto_dsm_grupo1.U_I.profile

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.proyecto_dsm_grupo1.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProfileScreen(
    onBack: () -> Unit = {},
    onSaved: () -> Unit = {},           // ← al guardar, volver a Configuración
    viewModel: EditProfileViewModel = viewModel()
) {
    // Colores consistentes con Login/Register
    val primaryGreen = Color(0xFF2DBE71)
    val lightGray    = Color(0xFFF3F5F4)

    LaunchedEffect(Unit) { viewModel.loadProfile() }

    // ---------- Estado de valores actuales ----------
    var nombre by rememberSaveable { mutableStateOf("") }
    var apellido by rememberSaveable { mutableStateOf("") }
    var nivel by rememberSaveable { mutableStateOf("") }
    var bio by rememberSaveable { mutableStateOf("") }

    // ---------- Estado de “edición activa” por campo ----------
    var editNombre by rememberSaveable { mutableStateOf(false) }
    var editApellido by rememberSaveable { mutableStateOf(false) }
    var editNivel by rememberSaveable { mutableStateOf(false) }
    var editBio by rememberSaveable { mutableStateOf(false) }

    // Dropdown
    val niveles = listOf("Secundaria", "Pregrado", "Posgrado", "Diplomado", "Autodidacta")
    var nivelExpanded by rememberSaveable { mutableStateOf(false) }

    // Al llegar profile por primera vez, asignar valores locales (no sobreescribir si ya editó)
    LaunchedEffect(viewModel.profile) {
        viewModel.profile?.let { p ->
            // sólo asignar si los campos locales están vacíos (evita pisar edición en curso)
            if (nombre.isBlank() && apellido.isBlank() && nivel.isBlank() && bio.isBlank()) {
                nombre = p.nombre
                apellido = p.apellido
                nivel = if (p.nivel.isNotBlank()) p.nivel else "Selecciona tu nivel"
                bio = p.bio
            }
        }
    }

    // ---------- Validaciones ----------
    val allValid = remember(nombre, apellido, nivel, bio) {
        nombre.isNotBlank() && apellido.isNotBlank() && nivel in niveles && bio.isNotBlank()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
    ) {
        // Fondo (mismo de la app)
        Image(
            painter = painterResource(id = R.drawable.screen),
            contentDescription = "Fondo",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            // Encabezado con degradado y título
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color(0xFF79C78C), Color(0xFF5DBB7A))))
                    .padding(top = 12.dp, bottom = 16.dp, start = 16.dp, end = 16.dp)
            ) {
                Text(
                    "Editar perfil",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.align(Alignment.CenterStart)
                )
            }

            // Tarjeta blanca con el formulario
            Card(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 16.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(Modifier.padding(horizontal = 16.dp, vertical = 16.dp)) {

                    // Logo pequeño arriba (opcional)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.logo_dsm_removebg_preview),
                            contentDescription = "Logo",
                            modifier = Modifier
                                .width(120.dp)
                                .padding(bottom = 8.dp)
                        )
                    }

                    // ====== Nombre ======
                    EditableTextRow(
                        label = "Nombre",
                        value = nombre,
                        enabled = editNombre,
                        onValueChange = { nombre = it },
                        onPencilClick = {
                            if (editNombre) {
                                // Revertir cambios
                                nombre = viewModel.profile?.nombre ?: ""
                            }
                            editNombre = !editNombre
                        },
                        primaryGreen = primaryGreen
                    )

                    // ====== Apellido ======
                    EditableTextRow(
                        label = "Apellido",
                        value = apellido,
                        enabled = editApellido,
                        onValueChange = { apellido = it },
                        onPencilClick = {
                            if (editApellido) {
                                apellido = viewModel.profile?.apellido ?: ""
                            }
                            editApellido = !editApellido
                        },
                        primaryGreen = primaryGreen
                    )

                    // ====== Nivel educativo (dropdown editable) ======
                    Text(
                        "Nivel educativo",
                        style = MaterialTheme.typography.labelLarge.copy(color = Color(0xFF2F3B45)),
                        modifier = Modifier.padding(bottom = 6.dp, top = 12.dp)
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Lápiz
                        IconButton(
                            onClick = {
                                if (editNivel) {
                                    nivel = viewModel.profile?.nivel ?: ""
                                    nivelExpanded = false
                                }
                                editNivel = !editNivel
                            }
                        ) {
                            Icon(Icons.Outlined.Edit, contentDescription = "Editar nivel", tint = primaryGreen)
                        }

                        Spacer(Modifier.width(4.dp))

                        // Dropdown solo editable si editNivel=true
                        Box(modifier = Modifier.weight(1f)) {
                            ExposedDropdownMenuBox(
                                expanded = nivelExpanded && editNivel,
                                onExpandedChange = {
                                    if (editNivel) nivelExpanded = !nivelExpanded
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = nivel,
                                    onValueChange = {},
                                    readOnly = true,
                                    trailingIcon = {
                                        ExposedDropdownMenuDefaults.TrailingIcon(expanded = nivelExpanded && editNivel)
                                    },
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier
                                        .menuAnchor()
                                        .fillMaxWidth(),
                                    enabled = editNivel,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = primaryGreen,
                                        unfocusedBorderColor = primaryGreen.copy(alpha = 0.5f),
                                        cursorColor = primaryGreen,
                                        disabledBorderColor = lightGray
                                    )
                                )
                                ExposedDropdownMenu(
                                    expanded = nivelExpanded && editNivel,
                                    onDismissRequest = { nivelExpanded = false }
                                ) {
                                    niveles.forEach { option ->
                                        DropdownMenuItem(
                                            text = { Text(option) },
                                            onClick = {
                                                nivel = option
                                                nivelExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // ====== Bio (multilínea) ======
                    Text(
                        "Bio",
                        style = MaterialTheme.typography.labelLarge.copy(color = Color(0xFF2F3B45)),
                        modifier = Modifier.padding(bottom = 6.dp, top = 12.dp)
                    )
                    Row(
                        verticalAlignment = Alignment.Top,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        IconButton(
                            onClick = {
                                if (editBio) bio = viewModel.profile?.bio ?: ""
                                editBio = !editBio
                            }
                        ) {
                            Icon(Icons.Outlined.Edit, contentDescription = "Editar bio", tint = primaryGreen)
                        }
                        Spacer(Modifier.width(4.dp))
                        OutlinedTextField(
                            value = bio,
                            onValueChange = { bio = it },
                            placeholder = { Text("Cuéntanos sobre ti...") },
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .weight(1f)
                                .heightIn(min = 120.dp),
                            minLines = 4,
                            maxLines = 6,
                            enabled = editBio,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = primaryGreen,
                                unfocusedBorderColor = primaryGreen.copy(alpha = 0.5f),
                                cursorColor = primaryGreen,
                                disabledBorderColor = lightGray
                            )
                        )
                    }

                    Spacer(Modifier.height(18.dp))

                    // Botones inferiores
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = onBack,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = Color.White,
                                contentColor = primaryGreen
                            )
                        ) { Text("Cancelar") }

                        Button(
                            onClick = {
                                // Llamar al ViewModel
                                viewModel.saveProfile(nombre = nombre, apellido = apellido, nivel = nivel, bio = bio)
                            },
                            enabled = allValid,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = primaryGreen,
                                contentColor = Color.White,
                                disabledContainerColor = primaryGreen.copy(alpha = 0.4f)
                            )
                        ) { Text("Guardar", fontWeight = FontWeight.SemiBold) }
                    }

                    if (!allValid) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "Completa todos los campos antes de guardar.",
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.labelLarge
                        )
                    }
                }
            }
        }
        // Dialogo de error
        if (viewModel.error != null) {
            AlertDialog(
                onDismissRequest = { viewModel.clearError() },
                title = { Text("Error") },
                text = { Text(viewModel.error ?: "") },
                confirmButton = {
                    TextButton(onClick = { viewModel.clearError() }) { Text("OK") }
                }
            )
        }

        LaunchedEffect(viewModel.success) {
            if (viewModel.success) {
                onSaved()
                viewModel.clearSuccess()
            }
        }
    }
}

/* ----------------- Composable helper para campos texto editables ----------------- */
@Composable
private fun EditableTextRow(
    label: String,
    value: String,
    enabled: Boolean,
    onValueChange: (String) -> Unit,
    onPencilClick: () -> Unit,
    primaryGreen: Color
) {
    Text(
        label,
        style = MaterialTheme.typography.labelLarge.copy(color = Color(0xFF2F3B45)),
        modifier = Modifier.padding(bottom = 6.dp, top = 12.dp)
    )
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        IconButton(onClick = onPencilClick) {
            Icon(Icons.Outlined.Edit, contentDescription = "Editar $label", tint = primaryGreen)
        }
        Spacer(Modifier.width(4.dp))
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.weight(1f),
            enabled = enabled,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = primaryGreen,
                unfocusedBorderColor = primaryGreen.copy(alpha = 0.5f),
                cursorColor = primaryGreen,
                disabledBorderColor = Color(0xFFF3F5F4)
            )
        )
    }
}
