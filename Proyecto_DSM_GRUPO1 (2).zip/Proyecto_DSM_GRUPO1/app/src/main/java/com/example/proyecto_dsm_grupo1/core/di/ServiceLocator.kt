package com.example.proyecto_dsm_grupo1.core.di

import com.example.proyecto_dsm_grupo1.core.catalog.CatalogRepository
import com.example.proyecto_dsm_grupo1.core.catalog.impl.FirestoreCatalogRepository
import com.example.proyecto_dsm_grupo1.core.usercourses.UserCoursesRepository
import com.example.proyecto_dsm_grupo1.core.usercourses.impl.FirestoreUserCoursesRepository

object ServiceLocator {
    // Ahora conectan a Firestore (produce la implementación real)
    val catalogRepo: CatalogRepository by lazy { FirestoreCatalogRepository() }
    val userCoursesRepo: UserCoursesRepository by lazy { FirestoreUserCoursesRepository() }

    // Usuario “simulado” para pruebas en local (puedes seguir usándolo si quieres)
    const val demoUid: String = "demo-uid-123"
}
