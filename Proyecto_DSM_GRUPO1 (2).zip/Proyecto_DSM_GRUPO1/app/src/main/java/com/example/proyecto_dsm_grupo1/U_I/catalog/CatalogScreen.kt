package com.example.proyecto_dsm_grupo1.U_I.catalog

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.proyecto_dsm_grupo1.core.models.Course

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CatalogScreen(
    onBack: () -> Unit,
    onCourseClick: (String) -> Unit,
    vm: CatalogViewModel = viewModel()
) {
    val primaryGreen = Color(0xFF2DBE71)
    val lightGray = Color(0xFFF3F5F4)

    Scaffold(
        topBar = {
            Surface(color = Color(0xFF79C78C)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "Volver", tint = Color.White)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Explorar",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.titleLarge
                    )
                }
            }
        }
    ) { inner ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(inner)
                .background(Color(0xFFF5F7FA))
        ) {
            // Buscador
            Box(
                modifier = Modifier
                    .padding(16.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White)
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextField(
                        value = vm.uiState.query,
                        onValueChange = vm::onQueryChange,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        placeholder = { Text("Buscar Curso") },
                        singleLine = true,
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            disabledContainerColor = Color.Transparent,
                            cursorColor = primaryGreen,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        )
                    )
                    Icon(
                        imageVector = Icons.Outlined.Search,
                        contentDescription = "Buscar",
                        tint = Color(0xFF334155)
                    )
                }
            }

            // Categorías con FilterChip (soporta selected sin borde manual)
            Column(Modifier.padding(horizontal = 16.dp)) {
                Text(
                    "Buscar por categoría",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(Modifier.height(8.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    vm.uiState.categories.forEach { cat ->
                        val selected = vm.uiState.selectedCategory == cat
                        FilterChip(
                            selected = selected,
                            onClick = { vm.onToggleCategory(cat) },
                            label = {
                                Text(
                                    cat,
                                    color = if (selected) primaryGreen else Color(0xFF334155)
                                )
                            },
                            shape = RoundedCornerShape(22.dp),
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = if (selected) primaryGreen.copy(alpha = 0.18f) else lightGray,
                                selectedContainerColor = primaryGreen.copy(alpha = 0.18f),
                                labelColor = if (selected) primaryGreen else Color(0xFF334155),
                            )
                        )
                    }
                }
            }

            // Lista de cursos
            Spacer(Modifier.height(8.dp))
            Text(
                "Cursos Recomendados",
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF0F172A)
                ),
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )

            if (vm.uiState.loading) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = primaryGreen)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(bottom = 18.dp)
                ) {
                    items(vm.uiState.filtered) { course ->
                        CourseCatalogItem(
                            course = course,
                            onClick = { onCourseClick(course.id) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CourseCatalogItem(
    course: Course,
    onClick: () -> Unit
) {
    ElevatedCard(
        modifier = Modifier
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = Color.White),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Placeholder imagen
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFF1F5F9)),
                contentAlignment = Alignment.Center
            ) { Text("🖼️") }

            Spacer(Modifier.width(12.dp))

            Column(Modifier.weight(1f)) {
                Text(
                    course.title,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold)
                )
                Text(course.level, style = MaterialTheme.typography.labelLarge, color = Color(0xFF0F172A))
                Spacer(Modifier.height(4.dp))
                val star = "★"
                Text(
                    "$star ${course.rating}  •  Por ${course.teacher}",
                    style = MaterialTheme.typography.labelMedium.copy(color = Color(0xFF64748B)),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
