package com.example.proyecto_dsm_grupo1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.navigation.compose.rememberNavController
import com.example.proyecto_dsm_grupo1.core.nav.AppNavHost
import com.example.proyecto_dsm_grupo1.ui.theme.Proyecto_DSM_GRUPO1Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Proyecto_DSM_GRUPO1Theme {
                val nav = rememberNavController()
                AppNavHost(nav)
            }
        }
    }
}
