package com.example.proyecto_dsm_grupo1.core.catalog.impl

import android.util.Log
import com.example.proyecto_dsm_grupo1.core.catalog.CatalogRepository
import com.example.proyecto_dsm_grupo1.core.models.Course
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

private const val TAG = "FirestoreCatalogRepo"

class FirestoreCatalogRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) : CatalogRepository {

    override suspend fun getCoursesCatalog(): List<Course> {
        return try {
            val snapshot = firestore.collection("courses").get().await()
            snapshot.documents.map { doc ->
                Course(
                    id = doc.id,
                    title = doc.getString("title") ?: "",
                    teacher = doc.getString("teacher") ?: "",
                    level = doc.getString("level") ?: "",
                    rating = (doc.getDouble("rating") ?: 0.0).toFloat(),
                    imageUrl = doc.getString("imageUrl"),                // nullable
                    description = doc.getString("description") ?: "",
                    tags = (doc.get("tags") as? List<*>)?.mapNotNull { it as? String } ?: emptyList()
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error al leer cursos desde Firestore", e)
            emptyList()
        }
    }
}