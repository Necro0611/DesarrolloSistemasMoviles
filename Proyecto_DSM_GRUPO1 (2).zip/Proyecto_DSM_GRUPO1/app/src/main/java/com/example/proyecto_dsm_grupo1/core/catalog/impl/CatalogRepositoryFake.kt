package com.example.proyecto_dsm_grupo1.core.catalog.impl

import com.example.proyecto_dsm_grupo1.core.catalog.CatalogRepository
import com.example.proyecto_dsm_grupo1.core.models.Course
import kotlinx.coroutines.delay

class CatalogRepositoryFake : CatalogRepository {

    // Catálogo “semilla” (por ahora hardcode)
    private val sample = listOf(
        Course(
            id = "c-db1",
            title = "Base de Datos I",
            teacher = "Joaquín L.",
            level = "Principiante",
            rating = 3.5f,
            description = "Fundamentos de modelos relacionales, SQL básico y normalización.",
            tags = listOf("bd", "sql", "relacional")
        ),
        Course(
            id = "c-ai1",
            title = "Inteligencia Artificial",
            teacher = "Pablo S.",
            level = "Principiante",
            rating = 4.0f,
            description = "Introducción a IA: búsqueda, heurísticas y agentes.",
            tags = listOf("ia", "búsqueda")
        ),
        Course(
            id = "c-mobile1",
            title = "Desarrollo de Sistemas Móviles",
            teacher = "Jonathan A.",
            level = "Avanzado",
            rating = 5.0f,
            description = "Kotlin + Jetpack Compose + arquitectura limpia.",
            tags = listOf("android", "compose", "arquitectura")
        ),
        Course(
            id = "c-web1",
            title = "Programación Web",
            teacher = "María R.",
            level = "Intermedio",
            rating = 4.4f,
            description = "Frontend moderno y patrones de SPA.",
            tags = listOf("web", "frontend")
        ),
        Course(
            id = "c-alg1",
            title = "Algoritmos y Estructuras de Datos",
            teacher = "Carlos V.",
            level = "Intermedio",
            rating = 4.7f,
            description = "Estructuras fundamentales y análisis de complejidad.",
            tags = listOf("algoritmos", "complejidad")
        )
    )

    override suspend fun getCoursesCatalog(): List<Course> {
        // Simula latencia de red para testear loaders
        delay(300)
        return sample
    }
}
