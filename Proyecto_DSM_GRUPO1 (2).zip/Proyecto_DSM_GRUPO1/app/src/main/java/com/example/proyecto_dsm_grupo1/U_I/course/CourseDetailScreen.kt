package com.example.proyecto_dsm_grupo1.U_I.course

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun CourseDetailScreen(
    courseId: String,
    onBack: () -> Unit,
    onAddedGoBack: () -> Unit
) {
    val primaryGreen = Color(0xFF2DBE71)
    val vm: CourseDetailViewModel = viewModel()

    // Cargar curso al entrar y cuando cambia el id
    LaunchedEffect(courseId) { vm.load(courseId) }

    // Observamos el estado
    val state = vm.uiState

    Scaffold(
        topBar = {
            Surface(color = Color(0xFF79C78C)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                        .padding(horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "Volver", tint = Color.White)
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Detalle del Curso",
                        color = Color.White,
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.titleLarge
                    )
                }
            }
        }
    ) { inner ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(inner)
                .background(Color(0xFFF5F7FA))
        ) {
            when {
                state.loading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = primaryGreen)
                    }
                }
                state.course != null -> {
                    val c = state.course!!
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                    ) {
                        // Imagen placeholder
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xFFF1F5F9)),
                            contentAlignment = Alignment.Center
                        ) { Text("🖼️") }

                        Spacer(Modifier.height(12.dp))

                        Text(c.title, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                        Text(c.level, style = MaterialTheme.typography.labelLarge, color = Color(0xFF0F172A))
                        Spacer(Modifier.height(6.dp))
                        val star = "★"
                        Text("$star ${c.rating} • Por ${c.teacher}", color = Color(0xFF64748B))

                        Spacer(Modifier.height(12.dp))
                        Text("Descripción", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))
                        Spacer(Modifier.height(6.dp))
                        Text(c.description, color = Color(0xFF334155))

                        Spacer(Modifier.weight(1f))

                        // Botón: deshabilitado mientras agrega o si ya fue agregado
                        Button(
                            onClick = { vm.addToUser(onAddedGoBack) },
                            enabled = !state.adding && !state.added,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = primaryGreen, contentColor = Color.White)
                        ) {
                            if (state.adding) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                                Spacer(Modifier.width(8.dp))
                                Text("Agregando...")
                            } else if (state.added) {
                                Text("Agregado", fontWeight = FontWeight.SemiBold)
                            } else {
                                Text("Añadir curso")
                            }
                        }

                        // Mostrar error localmente (si existe)
                        state.error?.let { err ->
                            Spacer(Modifier.height(8.dp))
                            Text(text = err, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
                else -> {
                    // estado final: error o curso no encontrado
                    Text(
                        text = state.error ?: "Curso no encontrado",
                        modifier = Modifier.align(Alignment.Center),
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }
        }
    }
}