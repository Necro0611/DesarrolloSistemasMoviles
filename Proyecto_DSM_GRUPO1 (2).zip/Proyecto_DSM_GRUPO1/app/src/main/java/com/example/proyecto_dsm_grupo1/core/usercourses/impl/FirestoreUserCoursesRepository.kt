package com.example.proyecto_dsm_grupo1.core.usercourses.impl

import android.util.Log
import com.example.proyecto_dsm_grupo1.core.models.Course
import com.example.proyecto_dsm_grupo1.core.models.UserCourse
import com.example.proyecto_dsm_grupo1.core.usercourses.UserCoursesRepository
import com.google.firebase.firestore.FieldValue
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

private const val TAG = "FirestoreUserCoursesRepo"

class FirestoreUserCoursesRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) : UserCoursesRepository {

    override suspend fun getUserCourses(uid: String): List<UserCourse> {
        return try {
            val snap = firestore.collection("users")
                .document(uid)
                .collection("my_courses")
                .get()
                .await()

            snap.documents.map { doc ->
                val courseId = doc.id
                val title = doc.getString("title") ?: ""
                val teacher = doc.getString("teacher") ?: ""
                val level = doc.getString("level") ?: ""
                val rating = (doc.getDouble("rating") ?: 0.0).toFloat()
                val progress = (doc.getDouble("progress") ?: 0.0).toFloat()
                val status = doc.getString("status") ?: "pending"
                val ts = doc.getTimestamp("addedAt")
                val addedMillis = ts?.toDate()?.time ?: (doc.getLong("addedAt") ?: 0L)

                UserCourse(
                    courseId = courseId,
                    title = title,
                    teacher = teacher,
                    level = level,
                    rating = rating,
                    progress = progress,
                    status = status,
                    addedAt = addedMillis
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "getUserCourses error", e)
            emptyList()
        }
    }

    override suspend fun addCourseToUser(uid: String, course: Course): UserCourse {
        val docRef = firestore.collection("users").document(uid)
            .collection("my_courses").document(course.id)

        // comprobar existencia
        val existingSnap = docRef.get().await()
        if (existingSnap.exists()) {
            // mapear y devolver el UserCourse existente
            val title = existingSnap.getString("title") ?: course.title
            val teacher = existingSnap.getString("teacher") ?: course.teacher
            val level = existingSnap.getString("level") ?: course.level
            val rating = (existingSnap.getDouble("rating") ?: course.rating.toDouble()).toFloat()
            val progress = (existingSnap.getDouble("progress") ?: 0.0).toFloat()
            val status = existingSnap.getString("status") ?: "pending"
            val ts = existingSnap.getTimestamp("addedAt")
            val addedMillis = ts?.toDate()?.time ?: (existingSnap.getLong("addedAt") ?: System.currentTimeMillis())

            return UserCourse(
                courseId = course.id,
                title = title,
                teacher = teacher,
                level = level,
                rating = rating,
                progress = progress,
                status = status,
                addedAt = addedMillis
            )
        }

        // si no existe, crear (tu lógica actual)
        val data = mapOf(
            "title" to course.title,
            "teacher" to course.teacher,
            "level" to course.level,
            "rating" to course.rating.toDouble(),
            "imageUrl" to course.imageUrl,
            "description" to course.description,
            "tags" to course.tags,
            "progress" to 0.0,
            "status" to "pending",
            "addedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
        )
        docRef.set(data).await()
        val saved = docRef.get().await()
        val ts = saved.getTimestamp("addedAt")
        val addedMillis = ts?.toDate()?.time ?: System.currentTimeMillis()

        return UserCourse(
            courseId = course.id,
            title = course.title,
            teacher = course.teacher,
            level = course.level,
            rating = course.rating,
            progress = 0f,
            status = "pending",
            addedAt = addedMillis
        )
    }

    override suspend fun removeUserCourse(uid: String, courseId: String) {
        try {
            firestore.collection("users")
                .document(uid)
                .collection("my_courses")
                .document(courseId)
                .delete()
                .await()
        } catch (e: Exception) {
            Log.e(TAG, "removeUserCourse error", e)
            throw e
        }
    }

    override suspend fun updateProgress(uid: String, courseId: String, progress: Float) {
        try {
            firestore.collection("users")
                .document(uid)
                .collection("my_courses")
                .document(courseId)
                .update(mapOf(
                    "progress" to progress.toDouble(),
                    // opcional: actualizar status en función del progreso
                    "status" to when {
                        progress >= 0.999 -> "done"
                        progress > 0f -> "in_progress"
                        else -> "pending"
                    }
                ))
                .await()
        } catch (e: Exception) {
            Log.e(TAG, "updateProgress error", e)
            throw e
        }
    }
}