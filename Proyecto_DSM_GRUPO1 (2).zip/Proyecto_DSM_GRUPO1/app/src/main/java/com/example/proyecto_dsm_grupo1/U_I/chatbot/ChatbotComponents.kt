package com.example.proyecto_dsm_grupo1.U_I.chatbot.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Attachment
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// mismo verde que en Screens
private val ChatGreen = Color(0xFF22C55E)

@Composable
fun MessageBubble(
    text: String,
    isMine: Boolean,
    timestamp: Date,
) {
    val bg = if (isMine) ChatGreen else MaterialTheme.colorScheme.surfaceVariant
    val content = if (isMine) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
    val alignment = if (isMine) Alignment.End else Alignment.Start
    val shape = RoundedCornerShape(
        topStart = 16.dp, topEnd = 16.dp,
        bottomEnd = if (isMine) 4.dp else 16.dp,
        bottomStart = if (isMine) 16.dp else 4.dp
    )
    val time = remember(timestamp) {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(timestamp)
    }

    Column(Modifier.fillMaxWidth(), horizontalAlignment = alignment) {
        Column(
            modifier = Modifier
                .widthIn(max = 320.dp)
                .clip(shape)
                .background(bg)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Text(text = text, color = content, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                text = time,
                color = content.copy(alpha = 0.85f),
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.End
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatComposer(
    value: String,
    onValueChange: (String) -> Unit,
    onSend: () -> Unit
) {
    Surface(tonalElevation = 3.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { /* Adjuntar (futuro) */ }) {
                Icon(Icons.Outlined.Attachment, contentDescription = "Adjuntar")
            }
            OutlinedTextField(
                modifier = Modifier.weight(1f),
                value = value,
                onValueChange = onValueChange,
                placeholder = { Text("Escribe tu mensaje...") },
                singleLine = true
            )
            Spacer(Modifier.width(6.dp))
            FilledIconButton(
                onClick = onSend,
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = ChatGreen,
                    contentColor = Color.White
                )
            ) {
                Icon(Icons.Outlined.Send, contentDescription = "Enviar")
            }
        }
    }
}
