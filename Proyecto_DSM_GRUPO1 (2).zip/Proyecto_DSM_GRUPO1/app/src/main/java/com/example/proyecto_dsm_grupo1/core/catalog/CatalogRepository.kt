package com.example.proyecto_dsm_grupo1.core.catalog

import com.example.proyecto_dsm_grupo1.core.models.Course

interface CatalogRepository {
    suspend fun getCoursesCatalog(): List<Course>
}
